Cara menjalankan proyek appointment dokter

1. clone project https://github.com/felixabel684/Appointment-BK.git
2. buat database dengan nama "appointment_bk"
3. pilih export, kemudian upload appointment_bk.sql
4. kemudian buka terminal
5. jalankan composer install & npm run build
6. lalu ketikkan cp .env.example .env
7. lalu ketikkan php artisan key:generate
8. lalu run dengan php artisan serve
9. Website dapat diakses melalui localhost (http://127.0.0.1:8000/)

List User
Admin
user  : admin
pw    : admin1234

Dokter
user  : david
pw    : david1234

Pasien
user  : 1122334455667788

   Selamat mencoba:)
