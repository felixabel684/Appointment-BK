<!-- Footer -->
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            ©2024 Poliklinik - Admin | All Rights Reserved
        </div>
    </div>
</footer>
<!-- End of Footer -->