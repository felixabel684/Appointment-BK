<link rel="stylesheet" href="{{ url('frontend/styles/main-2.css') }}" />
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet" />
<link rel="stylesheet" href="{{ url('frontend/styles/main.css') }}" />