<div class="container">
    <nav class="row navbar navbar-expand-lg navbar-light bg-white">
        <div class="navbar-nav mx-auto justify-content-center">
            <a class="navbar-brand" href="{{ url('/') }}">
                <img src="{{ url('frontend/images/logopoliklinik.png') }}" alt=""/>
            </a>
        </div>
    </nav>
</div>
