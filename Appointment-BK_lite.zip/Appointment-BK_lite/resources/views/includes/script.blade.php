<script src="{{url('frontend/scripts/main.js')}}"></script>
<script src="{{url('frontend/libraries/vendor/bootstrap/js/bootstrap.js')}}"></script>